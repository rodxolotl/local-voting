let int _cap = Random.int
let get_state _cap = Random.get_state
