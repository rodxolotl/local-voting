let argv _cap = Sys.argv
let set_signal _cap = Sys.set_signal
let chdir _cap = Sys.chdir
