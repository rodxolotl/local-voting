let execvp _caps = Unix.execvp
let system _caps = Unix.system
let fork _caps = Unix.fork
let alarm _caps = Unix.alarm
let setitimer _caps = Unix.setitimer
