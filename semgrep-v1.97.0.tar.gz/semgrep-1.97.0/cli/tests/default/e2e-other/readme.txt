Those are e2e tests that concern features (e.g., sca, secrets, semgrep login,
semgrep ci) that ultimately would move to semgrep-pro.
