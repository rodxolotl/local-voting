<!--
   Unfortunately GitHub doesn't render symlinks as clickable, otherwise
   this file would be a symlink.
-->

Thank you for your interest in contributing to the Semgrep source code!

Find contribution guidelines in **[Semgrep documentation](https://semgrep.dev/docs/contributing/contributing/)**.

Specifically, see **[Contributing code](https://semgrep.dev/docs/contributing/contributing-code/)** to contribute either to Semgrep source code or semgrep-core source code.
